#include<iostream>
#include<Windows.h>
#include<conio.h>
#include <time.h>
#include <fstream>
#include <cwchar>
using namespace std;

//setting new kind of structure-board
struct board{
    int X,Y;  //X for Width and Y for length
    int grid[80][80];  // Position of icons
    char players[2][20];  // The name of the two players
    int games=0;  //Number of games played
    int win_cond[2]={0}; //Streak_counter to see if each player have the right condition to win
    int win_counter[2]={0};  //Number of match won
    int lost_counter[2]={0};  //Number of match won
    int Cursor;  // Cursor position
    int streak;  // The numeber of icon in a row to be the winner
    int Color;//color
    int check_valid=0;//check for valid
    int suggestion;// suggestion for the player
    int mode; // pve or PvP
    int replayability[2]={3,3};
};

//Print vertical line
void verline(int size) {
    for (int i = 0; i <= size - 1; i++) {
        cout << "        |";
    }
    cout << endl;
}

//print horizontal line
void horline(int size) {
    for (int i = 0; i <= size - 1; i++) {
        cout << " --------";
    }
    cout << endl;
}


//Print the board with included cursor and move suggestion;
void PrintBoard(board B){
    int i;
    int coordinate_x_cursor = B.Cursor%B.X;
    int coordinate_y_cursor = B.Cursor/B.X;
    int coordinate_x_sugg = B.suggestion%B.X;
    int coordinate_y_sugg = B.suggestion/B.X;
    for(i = 0; i < B.Y; i++){
        horline(B.X);
        cout << "|";
        verline(B.X);
        cout << "|";
        for( int j = 0; j < B.X; j++){
            if (j == coordinate_x_cursor && i == coordinate_y_cursor){
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
                if(B.grid[j][i] != 0 ){
                    for (int g = 0; g < (8 - strlen(B.players[B.grid[j][i]-1])) / 2; g++){
                        cout << " ";
                    }
                    cout << B.players[B.grid[j][i]-1];
                    for (int h = 0; h < 8 - ((8 - strlen(B.players[B.grid[j][i]-1]))/2) - strlen(B.players[B.grid[j][i]-1]); h++){
                        cout << " ";
                    }
                }
                if(B.grid[j][i] == 0 ){
                    cout<<"  >" << " " <<" <  ";
                }
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                cout<<"|";
            }
            else if(B.grid[j][i] == 0 && j == coordinate_x_sugg && i == coordinate_y_sugg){
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
                    cout<<"  >" << " " <<" <  ";
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                cout<<"|";
            }
            else if(B.grid[j][i] != 0){
                if(B.grid[j][i] == 1){
                    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 1);
                }
                else if (B.grid[j][i] == 2){
                    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
                }
                for (int g = 0; g < (8 - strlen(B.players[B.grid[j][i]-1])) / 2; g++){
                    cout << " ";
                }
                cout << B.players[B.grid[j][i]-1];
                for (int h = 0; h < 8 - ((8 - strlen(B.players[B.grid[j][i]-1]))/2) - strlen(B.players[B.grid[j][i]-1]); h++){
                    cout << " ";
                }
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                cout<<"|";
            }
            else{
                cout<<"        |";
            } 
        }
        cout << endl;
        cout << "|";
        verline(B.X);
        horline(B.X);
    }
}

// Player 1's turn to play
void player_1_turn(board &B){
    B.suggestion = rand()%(B.X*B.Y);//Move suggestion
    while(B.grid[B.suggestion%B.X][B.suggestion/B.X] != 0 && B.check_valid != 0){
        B.suggestion = rand()%(B.X*B.Y);
    }
    char c = ' ';
    while(c != 13){
        B.check_valid = 0;
        for(int i = 0; i < B.X ; i++){
            for(int j = 0; j < B.Y ; j++){
                if(B.grid[j][i]==0){
                    B.check_valid++;
                }
            }
        }
        if( B.check_valid == 0){
            cout<<"You have no where to move, it's a lose-lose situation.";
            B.games++;
            Sleep(3700);
            break;
        }
        else{
            system("cls");
            cout<<"Use A,S,D,W to move.\n";
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
            cout << "The yellow cursor is a hint for you ;)\n";
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),B.Color);
            cout<<"Press enter to put your icon into current position.\n \n ";
            PrintBoard(B);
            c = _getch();
            switch(c){
                case 'w':{
                    if(B.Cursor >= B.X){
                        B.Cursor -= B.X;
                    }
                    break;
                }
                case 's':{
                    if(B.Cursor <= B.X * ( B.Y - 1 ) - 1){
                        B.Cursor += B.X;
                    }
                    break;
                }
                case 'a':{
                    if(B.Cursor > 0){
                        B.Cursor -=1;
                    }
                    break;
                }
                case 'd':{
                    if(B.Cursor < B.X * B.Y -1){
                        B.Cursor +=1;
                    }
                    break;
                }
                case 13:{
                    if(B.grid[B.Cursor%B.X][B.Cursor/B.X] == 0){
                        B.grid[B.Cursor%B.X][B.Cursor/B.X]=1;
                    }
                    else{
                        cout << "This move is illegal";
                        c='0';
                        Sleep(1000);
                    }
                    break;
                }
            }
        }
    }
    system("cls");
    PrintBoard(B);
}

// Player 2's turn to play
void player_2_turn(board &B){
    B.suggestion = rand()%(B.X*B.Y);//Move suggestion
    while(B.grid[B.suggestion%B.X][B.suggestion/B.X] != 0 && B.check_valid != 0){
        B.suggestion = rand()%(B.X*B.Y);
    }
    char c = ' ';
    while(c != 13){
        B.check_valid = 0;
        for(int i = 0; i < B.X ; i++){
            for(int j = 0; j < B.Y ; j++){
                if(B.grid[j][i]==0){
                    B.check_valid++;
                }
            }
        }
        if( B.check_valid == 0){
            cout<<"You have no where to move, it's a lose-lose situation.";
            B.games++;
            Sleep(3700);
            break;
        }
        else{
            system("cls");
            cout<<"Use A,S,D,W to move.\n";
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
            cout << "The yellow cursor is a hint for you ;)\n";
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),B.Color);
            cout<<"Press enter to put your icon into current position.\n \n ";
            PrintBoard(B);
            c = _getch();
            switch(c){
                case 'w':{
                    if(B.Cursor >= B.X){
                        B.Cursor -= B.X;
                    }
                    break;
                }
                case 's':{
                    if(B.Cursor <= B.X * ( B.Y - 1 ) - 1){
                        B.Cursor += B.X;
                    }
                    break;
                }
                case 'a':{
                    if(B.Cursor > 0){
                        B.Cursor -=1;
                    }
                    break;
                }
                case 'd':{
                    if(B.Cursor < B.X * B.Y -1){
                        B.Cursor +=1;
                    }
                    break;
                }
                case 13:{
                    if(B.grid[B.Cursor%B.X][B.Cursor/B.X] == 0){
                        B.grid[B.Cursor%B.X][B.Cursor/B.X]=2;
                    }
                    else{
                        cout << "This move is illegal";
                        c='0';
                        Sleep(1000);
                    }
                    break;
                }
            }
        }
    }
    B.suggestion = rand()%(B.X*B.Y);//Move suggestion
    while(B.grid[B.suggestion%B.X][B.suggestion/B.X] != 0 && B.check_valid != 0){
        B.suggestion = rand()%(B.X*B.Y);
    }
    system("cls");
    PrintBoard(B);
}

//Move replay
void replay(int player, board &B){
    if(B.replayability[player - 1] > 0 ){
        char c = ' ';
        while(c != 13){
            system("cls");
            cout<<"Use A,S,D,W to move.\n";
            cout<<"Press enter to put your icon into current position.\n \n ";
            PrintBoard(B);
            c = _getch();
            switch(c){
                case 'w':{
                    if(B.Cursor >= B.X){
                        B.Cursor -= B.X;
                    }
                    break;
                }
                case 's':{
                    if(B.Cursor <= B.X * ( B.Y - 1 ) - 1){
                        B.Cursor += B.X;
                    }
                    break;
                }
                case 'a':{
                    if(B.Cursor > 0){
                        B.Cursor -=1;
                    }
                    break;
                }
                case 'd':{
                    if(B.Cursor < B.X * B.Y -1){
                        B.Cursor +=1;
                    }
                    break;
                }
                case 13:{
                    if(B.grid[B.Cursor%B.X][B.Cursor/B.X] == player){
                        B.grid[B.Cursor%B.X][B.Cursor/B.X]=0;
                        B.replayability[player-1] -= 1;
                    }
                    if(B.grid[B.Cursor%B.X][B.Cursor/B.X] == 0){
                        cout << "There is nothing here!" << "\n";
                    }
                }
            }
        }
    }
}

//Ask for replay
void askReplay(int player,board &B){
    char option = ' ';
    if (B.replayability[player-1] >0){
        while(option != 'y' && option != 'n'){
            cout << "Do you want to correct your mistakes "<< "you have "<< B.replayability[player-1] << " chances" <<"? y/n" << endl; 
            option = _getch();
            if(option == 'y'){
                replay(player, B);
                if(player == 1){
                    player_1_turn(B);
                }
                if(player == 2){
                    player_2_turn(B);
                }
            }
        }
    }
}

//pve mode
void Pve(board &B){
    B.Cursor = rand()%(B.X*B.Y);//Move Cursor
    B.check_valid = 0;
    for(int i = 0; i < B.X ; i++){
        for(int j = 0; j < B.Y ; j++){
            if(B.grid[j][i]==0){
                B.check_valid++;
            }
        }
    }
    while(B.grid[B.Cursor%B.X][B.Cursor/B.X] != 0 && B.check_valid != 0){
        B.Cursor = rand()%(B.X*B.Y);
    }
    B.suggestion = rand()%(B.X*B.Y);//Move suggestion
    while(B.grid[B.suggestion%B.X][B.suggestion/B.X] != 0 && B.check_valid != 0){
        B.suggestion = rand()%(B.X*B.Y);
    }
    B.grid[B.Cursor%B.X][B.Cursor/B.X]=2;
}

//Check winning condition for columns
void  CheckColumn(board &B){
    for(int i = 0; i < B.X;i++){
        for(int j=0; j < B.Y; j++){
            if(B.grid[j][i] == 1){
                B.win_cond[0]++;
                if(j== B.Y-1 &&  B.win_cond[0]< B.streak ) B.win_cond[0]=0;
                if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
            }
            if(B.grid[j][i] == 2){
                B.win_cond[1]++;
                if(j== B.Y-1 &&  B.win_cond[1]< B.streak ) B.win_cond[1]=0;
                if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
            }
            if(B.grid[j][i] == 0){
                if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
                if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
            }
            if(B.win_cond[0]==B.streak){
                B.games+=1;
                B.win_counter[0]+=1;
                B.lost_counter[1]+=1;
                cout<<"Player_1 won the game!\n";
                B.win_cond[0]={0};
                B.win_cond[1]={0};
                return;
            }
            if(B.win_cond[1]==B.streak){
                B.games+=1;
                B.win_counter[1]+=1;
                B.lost_counter[0]+=1;
                cout<<"Player_2 won the game!\n";
                B.win_cond[0]={0};
                B.win_cond[1]={0};
                return;
            }
        }
    }
}

//Check winning condition for Rows
void  CheckRow(board &B){
    for(int j = 0; j < B.Y;j++){
        for(int i=0; i < B.X; i++){
            if(B.grid[j][i] == 1){
                B.win_cond[0]++;
                if(i== B.X-1 &&  B.win_cond[0]< B.streak ) B.win_cond[0]=0;
                if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
            }
            if(B.grid[j][i] == 2){
                B.win_cond[1]++;
                if(i== B.X-1 &&  B.win_cond[1]< B.streak ) B.win_cond[1]=0;
                if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
            }
            if(B.grid[j][i] == 0){
                if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
                if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
            }
            if(B.win_cond[0]==B.streak){
                B.games+=1;
                B.win_counter[0]+=1;
                B.lost_counter[1]+=1;
                cout<<"Player_1 won the game!\n";
                B.win_cond[0]={0};
                B.win_cond[1]={0};
                return;
            }
            if(B.win_cond[1]==B.streak){
                B.games+=1;
                B.win_counter[1]+=1;
                B.lost_counter[0]+=1;
                cout<<"Player_2 won the game!\n";
                B.win_cond[0]={0};
                B.win_cond[1]={0};
                return;
            }
        }
    }
}

// Check main diagonal lines
void CheckDiagMain(board &B){
    for(int count_y = 0; count_y + (B.streak-1) < B.Y; count_y++){
        for(int count_x = 0; count_x + (B.streak-1) < B.X; count_x++){
            int j = count_y;
            for(int i = count_x; (i < (count_x + B.streak)) && (j < (count_y+ B.streak)); i++){
                if(B.grid[j][i] == 1){
                    B.win_cond[0]++;
                    if(i==(count_x+B.streak-1) && B.win_cond[0]<B.streak) B.win_cond[0]=0;
                    if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
                }
                if(B.grid[j][i] == 2){
                    B.win_cond[1]++;
                    if(i==(count_x+B.streak-1) && B.win_cond[1]<B.streak) B.win_cond[1]=0;
                    if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
                }
                if(B.grid[j][i] == 0){
                    if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
                    if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
                }
                if(B.win_cond[0]==B.streak){
                    B.games+=1;
                    B.win_counter[0]+=1;
                    B.lost_counter[1]+=1;
                    cout<<"Player_1 won the game!\n";
                    B.win_cond[0]={0};
                    B.win_cond[1]={0};
                    return;
                }
                if(B.win_cond[1]==B.streak){
                    B.games+=1;
                    B.win_counter[1]+=1;
                    B.lost_counter[0]+=1;
                    cout<<"Player_2 won the game!\n";
                    B.win_cond[0]={0};
                    B.win_cond[1]={0};
                    return;
                }
                j++;
            }
        }
    }   
}

//Check diagonal secodary lines
void CheckDiagSec(board &B){
    for(int count_y = B.Y-1 ; count_y - (B.streak-1) >= 0; count_y--){
        for(int count_x = 0; count_x + (B.streak-1) <B.X; count_x++){
            int j=count_y;
            for(int i = count_x; (i < (count_x + B.streak)) && (j > (count_y-B.streak)); i++){
                if(B.grid[j][i] == 1){
                    B.win_cond[0]++;
                    if(i==(count_x+B.streak-1) && B.win_cond[0]<B.streak) B.win_cond[0]=0;
                    if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
                }
                if(B.grid[j][i] == 2){
                    B.win_cond[1]++;
                    if(i==(count_x+B.streak-1) && B.win_cond[1]<B.streak) B.win_cond[1]=0;
                    if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
                }
                if(B.grid[j][i] == 0){
                    if(B.win_cond[0]<B.streak) B.win_cond[0]=0;
                    if(B.win_cond[1]<B.streak) B.win_cond[1]=0;
                }
                if(B.win_cond[0]==B.streak){
                    B.games+=1;
                    B.win_counter[0]+=1;
                    B.lost_counter[1]+=1;
                    cout<<"Player_1 won the game!\n";
                    B.win_cond[0]={0};
                    B.win_cond[1]={0};
                    return;
                }
                if(B.win_cond[1]==B.streak){
                    B.games+=1;
                    B.win_counter[1]+=1;
                    B.lost_counter[0]+=1;
                    cout<<"Player_2 won the game!\n";
                    B.win_cond[0]={0};
                    B.win_cond[1]={0};
                    return;
                }
                j--;
            }
        }
    }
}

//Reset board after each games
void ResetBoard(board &B){
    for(int i=0; i< 80-1; i++){
        for(int j=0; j< 80-1; j++){
            B.grid[i][j]=0;
        }
    }
}

void loadGame(board &B){
    ifstream in("saveGame.txt");
    if(!in.is_open()){
        cout <<"no save file\n";
        cout << "Choose game mode:"<< endl;
        cout <<"    a.PvP" << endl;
        cout <<"    b.PvE" << endl;
        cout <<"Enter your option : ";
        B.mode = _getch();
        return;
    }
    in >> B.X;
    in >> B.Y;
    in >> B.streak;
    in >> B.players[0];
    in >> B.players[1];
    in >> B.games;
    in >> B.win_counter[0];
    in >> B.win_counter[1];
    in >> B.lost_counter[0];
    in >> B.lost_counter[1];
    in >> B.Color;
    in >> B.mode;
    in.close();
}

void saveGame(board &B){
    ofstream out("saveGame.txt");
    out << B.X << "\n";
    out << B.Y << "\n";
    out << B.streak <<"\n";
    out << B.players[0] << "\n";
    out << B.players[1] << "\n";
    out << B.games << "\n";
    out << B.win_counter[0] << "\n";
    out << B.win_counter[1] << "\n";
    out << B.lost_counter[0] << "\n";
    out << B.lost_counter[1] << "\n";
    out << B.Color << "\n";
    out << B.mode << "\n";
    out.close();
}

int main(){
    srand(time(0));
    //Welcoming screen
    cout<<" ________  ______   ______         ________   ______    ______         ________   ______   ________ \n";
    cout<<"/        |/      | /      L       /        | /      L  /      L       /        | /      L /        |\n";
    cout<<"$$$$$$$$/ $$$$$$/ /$$$$$$  |      $$$$$$$$/ /$$$$$$  |/$$$$$$  |      $$$$$$$$/ /$$$$$$  |$$$$$$$$/ \n";
    cout<<"   $$ |     $$ |  $$ |  $$/          $$ |   $$ |__$$ |$$ |  $$/          $$ |   $$ |  $$ |$$ |__    \n";
    cout<<"   $$ |     $$ |  $$ |               $$ |   $$    $$ |$$ |               $$ |   $$ |  $$ |$$    |   \n";
    cout<<"   $$ |     $$ |  $$ |   __          $$ |   $$$$$$$$ |$$ |   __          $$ |   $$ |  $$ |$$$$$/    \n";
    cout<<"   $$ |    _$$ |_ $$ L__/  |         $$ |   $$ |  $$ |$$ L__/  |         $$ |   $$ L__$$ |$$ |_____ \n";
    cout<<"   $$ |   / $$   |$$    $$/          $$ |   $$ |  $$ |$$    $$/          $$ |   $$    $$/ $$       |\n";
    cout<<"   $$/    $$$$$$/  $$$$$$/           $$/    $$/   $$/  $$$$$$/           $$/     $$$$$$/  $$$$$$$$/ \n";
    cout<<"\n";
    //The rule
    cout << "           THE INTRODUCTION AND GAME RULES:\n";
    cout << "-Welcome to the legendary game of wits from every student's childhood !\n";
    cout << "-The rules are simple. Each players, take turns to place their icons on the board! The first to get\n a certain amount of icons in a straight line first is the winner.\n";
    cout << "-have fun and good luck!\n";
    //creaưte the board
    board B;
    cout << "           LET'S PLAY TIC-TAC-TOE !!!" << endl;
    cout << " Do you want to load a previous game from the computer? Y/n ? \n";
    char option;
    option = _getch();

    if(option == 'Y' || option == 'y'){
        loadGame(B);
    }
    else {
        cout << "Choose game mode:"<< endl;
        cout <<"    a.PvP" << endl;
        cout <<"    b.PvE" << endl;
        cout <<"Enter your option : ";
        B.mode = _getch();
    }
    switch (B.mode){
        
        case 'b':{
            cout<<"Set up players' names\n";
            cout<<"     Enter player 1's name:";
            cin>>B.players[0];
            cout<<"     Enter your opponent's name':";
            cin>>B.players[1];
            cout<<"\n";

            //Color selection
            char color_scheme;
            cout <<"But first, are you okay with this color scheme? The option are:"<<"\n";
            cout <<"                a.black text, white backgroud\n";
            cout <<"                else. default white text, black background\n";
            cout <<"Please, decide:";
            cin >>color_scheme;
            switch (color_scheme)
            {
            case 'a':
            case 'A':
                B.Color=112;
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                break;
            default:
                B.Color=15;
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                break;
            }
            cout<<"\n";

            //Board measures width and length
            cout<<"THE BOARD'S MEASURES:\n";
            cout<<"DISCLAIMER: -Width and Length must be greater or equal to 3.\n";
            cout<<"            -If Width or Length is equal to 3, the winning condition is automaticly set to 3.\n";
            cout<<"Enter the width of the board:";
            cin>>B.X;
            while (B.X<3){
                cout<<"Please, re-enter the Width:";
                cin>>B.X;
            }
            cout<<"Enter the Lenght of the board:";

            cin>>B.Y;
                while (B.Y<3){
                cout<<"Please, re-enter the Length:";
                cin>>B.Y;
            }

            //winning condition
            if(B.X==3 || B.Y==3){
                cout<<"Winning condition is automatically set to 3\n";
                B.streak=3;
            }
            else{
                cout<<"Enter the desired winning condition:\n";
                cin>>B.streak;
            }
            cout<<"\n";

            //set cursor
            B.Cursor=0;

            //clear game
            system("cls");

            //play game
            char repeat= ' ';
            while(repeat != 'n' ){
                ResetBoard(B);
                int temp = B.games;
                while( true){
                    B.check_valid=0;
                    player_1_turn(B);
                    askReplay(1, B);
                    CheckColumn(B);
                    CheckRow(B);
                    CheckDiagMain(B);
                    CheckDiagSec(B);
                    if( B.games > temp){
                        break;
                    }
                    Pve(B);
                    CheckColumn(B);
                    CheckRow(B);
                    CheckDiagMain(B);
                    CheckDiagSec(B);
                    if( B.games > temp){
                        break;
                    }
                }
                cout<<"-Games played:"<< B.games<<endl;
                cout<<"-Player 1 won:"<< B.win_counter[0]<<" games"<<"       "<<" lost:"<<B.lost_counter[0]<< " games"<<endl;
                cout<<"-Bot won:"<< B.win_counter[1]<<" games"<<"       "<<" lost:"<<B.lost_counter[1]<< " games"<<endl;
                cout<<"DO YOU WANT TO CONTINUE? y/n? press \"y\"to continue, press \"n\" to stop."<<endl;
                cout<< "insert:";
                repeat=_getch();
            }
            cout<<"\n";
            if (B.win_counter[0] > B.win_counter[1]){
                cout<<B.players[0] << " is the final winner!";
            }
            else if (B.win_counter[1] > B.win_counter[0]){
                cout<<B.players[1] << " is the final winner!";
            }
            else {
                cout<<"This is a draw !";
            }
            break;
        }
        case 'a':{
                cout<<"Set up players' names\n";
            cout<<"     Enter player 1's name:";
            cin>>B.players[0];
            cout<<"     Enter player 2's name:";
            cin>>B.players[1];
            cout<<"\n";

            //Color selection
            char color_scheme;
            cout <<"But first, are you okay with this color scheme? The option are:"<<"\n";
            cout <<"                a.black text, white backgroud\n";
            cout <<"                else. default white text, black background\n";
            cout <<"Please, decide:";
            cin >>color_scheme;
            switch (color_scheme)
            {
            case 'a':
            case 'A':
                B.Color=112;
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                break;
            default:
                B.Color=15;
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), B.Color);
                break;
            }
            cout<<"\n";

            //Board measures width and length
            cout<<"THE BOARD'S MEASURES:\n";
            cout<<"DISCLAIMER: -Width and Length must be greater or equal to 3.\n";
            cout<<"            -If Width or Length is equal to 3, the winning condition is automaticly set to 3.\n";
            cout<<"Enter the width of the board:";
            cin>>B.X;
            while (B.X<3){
                cout<<"Please, re-enter the Width:";
                cin>>B.X;
            }
            cout<<"Enter the Lenght of the board:";

            cin>>B.Y;
                while (B.Y<3){
                cout<<"Please, re-enter the Length:";
                cin>>B.Y;
            }

            //winning condition
            if(B.X==3 || B.Y==3){
                cout<<"Winning condition is automatically set to 3\n";
                B.streak=3;
            }
            else{
                cout<<"Enter the desired winning condition:\n";
                cin>>B.streak;
            }
            cout<<"\n";

            //set cursor
            B.Cursor=0;

            //clear game
            system("cls");

            //play game
            char repeat= ' ';
            while(repeat != 'n' ){
                ResetBoard(B);
                int temp = B.games;
                while( true){
                    B.check_valid=0;
                    player_1_turn(B);
                    askReplay(1, B);
                    CheckColumn(B);
                    CheckRow(B);
                    CheckDiagMain(B);
                    CheckDiagSec(B);
                    if( B.games > temp){
                        break;
                    }
                    player_2_turn(B);
                    askReplay(2, B);
                    CheckColumn(B);
                    CheckRow(B);
                    CheckDiagMain(B);
                    CheckDiagSec(B);
                    if( B.games > temp){
                        break;
                    }
                }
                cout<<"-Games played:"<< B.games<<endl;
                cout<<"-Player 1 won:"<< B.win_counter[0]<<" games"<<"       "<<" lost:"<<B.lost_counter[0]<< " games"<<endl;
                cout<<"-Player 2 won:"<< B.win_counter[1]<<" games"<<"       "<<" lost:"<<B.lost_counter[1]<< " games"<<endl;
                cout<<"DO YOU WANT TO CONTINUE? y/n? press \"y\"to continue, press \"n\" to stop."<<endl;
                cout<< "insert:";
                repeat=_getch();
            }
            cout<<"\n";
            if (B.win_counter[0] > B.win_counter[1]){
                cout<<B.players[0] << " is the final winner!";
            }
            else if (B.win_counter[1] > B.win_counter[0]){
                cout<<B.players[1] << " is the final winner!";
            }
            else {
                cout<<"This is a draw !";
            }
            break;
        }
    }
    cout << "Do you want to save your game? press \"y\" to save" << "\n";
    char end = ' ';
    end = _getch();
    if(end == 'Y' || end == 'y'){
        saveGame(B);
    }
    else return 0;
}     